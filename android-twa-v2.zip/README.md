# SIGO Android

Contenedor Android Trusted Web Activity para `https://www.sigo-gestion.com/`.

- Application ID: `com.sigo.gestion`
- Version code: `1`
- Version name: `1.0.0`
- Compile SDK: `36`
- Target SDK: `35`
- Minimum SDK: `23`

El bundle de CI se genera sin firma. La firma se realiza fuera del repositorio
con la clave privada de carga de SIGO, que nunca debe publicarse en Git.
